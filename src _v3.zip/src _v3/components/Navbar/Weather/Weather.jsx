// import React from "react";
// import classes from './Weather.module.css'
//
// const api ={
//     key: 541b31a4235f2aefa7d9de3df561c96f,
//     base:
// }
//
//  const  Weather = () =>{
//     return(
//         <div className={classes.wheather__app}>
//             <p>sdadsd</p>
//
//         </div>
//     )
// };
// export default Weather;